
class Base {
    constructor(id, name, description, available) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.available = available;
    }
}

module.exports = Base;