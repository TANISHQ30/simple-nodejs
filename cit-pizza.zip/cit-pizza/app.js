const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const ejsLint = require('ejs-lint');

let sqlite3 = require('sqlite3').verbose();

/* Load database file (Creates file if not exists) */
let db = new sqlite3.Database('./sqlite.db');

// sqlite config
const database = require('./config/dbconfig');

const BaseDB = require('./config/basedb');
const baseDB = new BaseDB();

/*const SauceDB = require('./config/saucedb');
const sauceDB = new SauceDB();*/

// dao 
/*const BaseDao = require('./dao/baseDao');
const baseDao = new BaseDao();*/

// init sqlite
database.init();

// set the view engine to ejs
app.set('view engine', 'ejs');

//express config
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// to use images
app.use( express.static( "images" ) );

app.use(express.static("views" + '../public'));

// express config
//app.use(bodyParser.urlencoded({extended: false}));
//app.use(bodyParser.json());

// use res.render to load up an ejs view file

// login page 
app.get('/', function(req, res) {
    console.log('/login');
    res.render('login/index');
    var u = document.getElementById("user");
    console.log(u);
});

// register page 
app.get('/register', function(req, res) {
    console.log('/register');
    res.render('register/index');
});

// home page 
app.get('/pizza', function(req, res) {
    console.log('/pizza');
    res.render('pizza/index');
});

// base home page 
app.get('/base', function(req, res) {
    
    console.log('/base');

    user = 'my user name111';
    bases = [];
    //bases = baseDB.findAllBases()
    let sql = `SELECT * FROM base ORDER BY id`;
        //var bases;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        } 
        rows.forEach((row) => {
            
            var base = {};
 
            base.id = row.id;
            base.name = row.name;
            base.description = row.description;
            base.available = row.available;
            base.price = row.price;
            base.image = row.image;
 
            bases.push(base);
        })
        
        res.render('base/index');
    })
});


// toppings home page 
app.get('/topping', function(req, res) {
    
    console.log('/topping');

    user = 'my user name111';
    toppings = [];
    //bases = baseDB.findAllBases()
    let sql = `SELECT * FROM topping ORDER BY id`;
        //var bases;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        } 
        rows.forEach((row) => {
            
            var topping = {};
 
            topping.id = row.id;
            topping.name = row.name;
            topping.description = row.description;
            topping.available = row.available;
            topping.image = row.image;
 
            toppings.push(topping);
        })
        
        res.render('topping/index');
    })

});

// sauce home page 
app.get('/sauce', function(req, res) {
    
    console.log('/sauce');

    user = 'my user name111';
    sauces = [];
    //bases = baseDB.findAllBases()
    let sql = `SELECT * FROM sauce ORDER BY id`;
        //var bases;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        } 
        rows.forEach((row) => {
            
            var sauce = {};
 
            sauce.id = row.id;
            sauce.name = row.name;
            sauce.description = row.description;
            sauce.available = row.available;
            sauce.image = row.image;
 
            sauces.push(sauce);
        })
        
        res.render('sauce/index');
    })

});

// sides home page 
app.get('/sides', function(req, res) {
    
    console.log('/sides');

    user = 'my user name111';
    sides = [];
    //bases = baseDB.findAllBases()
    let sql = `SELECT * FROM sides ORDER BY id`;
        //var bases;
    db.all(sql, [], (err, rows) => {
        if (err) {
            throw err;
        } 
        rows.forEach((row) => {
            
            var side = {};
 
            side.id = row.id;
            side.name = row.name;
            side.description = row.description;
            side.available = row.available;
            side.cost = row.cost;
            side.image = row.image;
 
            sides.push(side);
        })
        
        res.render('sides/index');
    })

});

// about page 
app.get('/about', function(req, res) {
    res.render('pages/about')});
    

/*app.get('/', function(req, res) {
    res.render('pizza/index');//res.render('pages/index');
});

// pizza page 
app.get('/pizza', function(req, res) {
    res.render('pizza/index');
});

// base home page 
app.get('/base', function(req, res) {
    res.render('base/index');
});

// toppings home page 
app.get('/topping', function(req, res) {
    res.render('topping/index');
});

// sauce home page 
app.get('/sauce', function(req, res) {
    res.render('sauce/index');
});

// sides home page 
app.get('/sides', function(req, res) {
    res.render('sides/index');
});

// about page 
app.get('/about', function(req, res) {
    res.render('pages/about');
}); */

// contact page 
app.get('/contact', function(req, res) {
    res.render('contact/index');
});

// cart page 
app.get('/cart', function(req, res) {
    res.render('cart/index');
});


app.listen(8080);
console.log('8080 is the magic port');
/*
// init server and define port
//const port = process.argv[2] || 3000;
//app.listen(port, function () {
//    console.log('server listening on port : ' + port);
//});



// router config
//const app_root = '/pizza';
//app.use(app_root, require('./app/routes/router'));*/