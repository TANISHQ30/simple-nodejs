/* Load modules */
let sqlite3 = require('sqlite3').verbose();

/*
 * Database configuration
 */

/* Load database file (Creates file if not exists) */
let db = new sqlite3.Database('./sqlite.db');

/* Init base, sauce and topping tables if they don't exist */
let init = function () {
    db.run("CREATE TABLE if not exists base (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        " name TEXT," +
        " description TEXT," +
        " available BOOLEAN," +
        " image TEXT" +
        ")");

    db.run("CREATE TABLE if not exists sauce (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        " name TEXT," +
        " description TEXT," +
        " available BOOLEAN," +
        " image TEXT" +
        ")");

    db.run("CREATE TABLE if not exists topping (" +
        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
        " name TEXT," +
        " description TEXT," +
        " available BOOLEAN," +
        " image TEXT" +
        ")");

    db.run("CREATE TABLE if not exists sides (" +
    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
    " name TEXT," +
    " description TEXT," +
    " cost DECIMAL," +
    " available BOOLEAN," +
    " image TEXT" +
    ")");
};

module.exports = {
    init: init,
    db: db
};

