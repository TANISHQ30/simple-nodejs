/* Load modules */
let sqlite3 = require('sqlite3').verbose();

/* Load database file (Creates file if not exists) */
let db = new sqlite3.Database('./sqlite.db');

class BaseDB {

    findAllBases() {

        let sql = `SELECT * FROM base ORDER BY name`;
        var bases;
        db.all(sql, [], (err, rows) => {
         
            bases = rows;
        if (err) {
            throw err;
        }
        rows.forEach((row) => {
            console.log('::',row.name);
        });
        });
        
        // close the database connection
        //db.close();

        return bases;

    }
}

module.exports = BaseDB;


